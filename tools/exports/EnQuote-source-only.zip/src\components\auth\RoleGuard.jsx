﻿import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/AuthContext";

const isLocalDemo = ["mock", "local", "salesforce-mock"].includes(import.meta.env.VITE_DATA_SOURCE);
import { Card } from "@/components/ui/card";
import { ShieldAlert } from "lucide-react";

export default function RoleGuard({ children, allowedRoles }) {
  const { isAuthenticated, user: authUser } = useAuth();
  const { data: queriedUser, isLoading: queryLoading } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => isAuthenticated && authUser ? authUser : base44.auth.me(),
    enabled: !isLocalDemo
  });
  const user = isLocalDemo ? authUser : queriedUser;
  const isLoading = isLocalDemo ? !authUser : queryLoading;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // If user doesn't have an app_role assigned yet
  if (!user?.app_role) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-amber-100 flex items-center justify-center">
            <ShieldAlert className="w-8 h-8 text-amber-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Role Not Assigned</h2>
          <p className="text-slate-600">
            Your account hasn't been assigned a role yet. Please contact an administrator to assign you a role (Submitter, Approver, or Admin).
          </p>
        </Card>
      </div>
    );
  }

  const userRoles = [user.app_role, ...(user.additional_roles || [])];
  // Check if the user has at least one required role
  if (allowedRoles && !allowedRoles.some(role => userRoles.includes(role))) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-rose-100 flex items-center justify-center">
            <ShieldAlert className="w-8 h-8 text-rose-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h2>
          <p className="text-slate-600 mb-1">
            You don't have permission to access this page.
          </p>
          <p className="text-sm text-slate-500">
            Your role: <span className="font-medium">{user.app_role}</span>
          </p>
        </Card>
      </div>
    );
  }

  return children;
}

// Hook to get current user role
export function useUserRole() {
  const { isAuthenticated, user: authUser } = useAuth();
  const { data: queriedUser, isLoading: queryLoading } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => isAuthenticated && authUser ? authUser : base44.auth.me(),
    enabled: !isLocalDemo
  });
  const user = isLocalDemo ? authUser : queriedUser;
  const isLoading = isLocalDemo ? !authUser : queryLoading;

  return {
    user,
    role: user?.app_role,
    roles: [user?.app_role, ...(user?.additional_roles || [])].filter(Boolean),
    isAdmin: [user?.app_role, ...(user?.additional_roles || [])].includes("admin"),
    isApprover: [user?.app_role, ...(user?.additional_roles || [])].some(role => ["approver", "admin"].includes(role)),
    isInvoicer: [user?.app_role, ...(user?.additional_roles || [])].includes("invoicer"),
    isSubmitter: [user?.app_role, ...(user?.additional_roles || [])].some(role => ["submitter", "approver", "admin"].includes(role)),
    isLoading
  };
}
