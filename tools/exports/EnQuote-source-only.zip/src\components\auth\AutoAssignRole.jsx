import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { ShieldAlert, Loader2 } from "lucide-react";

// Users who always get admin role regardless of invitation
const FORCED_ADMIN_EMAILS = ["vseganos@enphaseenergy.com"];

export default function AutoAssignRole({ children }) {
  const queryClient = useQueryClient();
  const [isChecking, setIsChecking] = useState(true);

  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const { data: invitation, isLoading: invitationLoading } = useQuery({
    queryKey: ["userInvitation", user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const invites = await base44.entities.Invitation.filter({ 
        email: user.email, 
        status: "pending" 
      });
      return invites[0] || null;
    },
    enabled: !!user?.email && !user?.app_role,
    staleTime: 0
  });

  const assignRoleMutation = useMutation({
    mutationFn: async () => {
      const role = FORCED_ADMIN_EMAILS.includes(user?.email) ? "admin" : (invitation?.invited_role || "submitter");
      
      await base44.auth.updateMe({ 
        app_role: role,
        account_setup_completed: true 
      });

      if (invitation?.id) {
        await base44.entities.Invitation.update(invitation.id, { 
          status: "accepted",
          accepted_date: new Date().toISOString()
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["currentUser"] });
      queryClient.invalidateQueries({ queryKey: ["userInvitation"] });
      queryClient.invalidateQueries({ queryKey: ["invitations"] });
      queryClient.invalidateQueries({ queryKey: ["users"] });
      setIsChecking(false);
    },
    onError: () => {
      setIsChecking(false);
    }
  });

  useEffect(() => {
    if (user && !userLoading && !invitationLoading) {
      const needsForceAdmin = FORCED_ADMIN_EMAILS.includes(user?.email) && user?.app_role !== "admin";
      if (!user.app_role && invitation) {
        assignRoleMutation.mutate();
      } else if (needsForceAdmin) {
        base44.auth.updateMe({ app_role: "admin" }).then(() => {
          queryClient.invalidateQueries({ queryKey: ["currentUser"] });
          setIsChecking(false);
        });
      } else {
        setIsChecking(false);
      }
    }
  }, [user, invitation, userLoading, invitationLoading]);

  // Show loading while checking invitation
  if (userLoading || invitationLoading || (isChecking && assignRoleMutation.isPending)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mx-auto mb-4" />
          <p className="text-slate-600">Setting up your account...</p>
        </div>
      </div>
    );
  }

  // If user has no app_role and no invitation, deny access
  if (user && !user.app_role && !invitation) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-rose-100 flex items-center justify-center">
            <ShieldAlert className="w-8 h-8 text-rose-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h2>
          <p className="text-slate-600 mb-4">
            This account has not been invited to use this system. Please contact an administrator to request access.
          </p>
          <button
            onClick={() => base44.auth.logout()}
            className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
          >
            Sign Out
          </button>
        </Card>
      </div>
    );
  }

  return children;
}