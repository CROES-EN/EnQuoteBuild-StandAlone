import { QUOTE_DRAFT_PROMPT } from "./quoteDraftPrompt";
import { buildQuotePayload } from "./quoteDraftMapper";
import { Ve } from "../../lib/base44";

export async function generateQuoteDraft(quote) {
    try {
        const payload = buildQuotePayload(quote);

        const prompt = `
${QUOTE_DRAFT_PROMPT}

QUOTE REQUEST DATA

${JSON.stringify(payload, null, 2)}

Return ONLY valid JSON.

Schema:

{
  "scopeOfWork": "",
  "homeownerSummary": "",
  "internalNotes": "",
  "riskStatement": "",
  "materials": [],
  "labor": [],
  "travel": [],
  "taxSummary": [],
  "quoteSummary": {}
}
`;

        const response =
            await Ve.integrations.Core.InvokeLLM({
                prompt
            });

        return response;
    }
    catch (error) {
        console.error(
            "Quote Draft Agent Error",
            error
        );

        throw error;
    }
}